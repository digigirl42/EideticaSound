!function ($) {
  $(function(){
	
	$('.dropdown-toggle').dropdown();
	
	$('.nav').scrollspy();
	
	$(".collapse").collapse();
	
	 
	
    // make code pretty
    window.prettyPrint && prettyPrint()
})
}(window.jQuery)